package it.gruppo5.museumadmin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Client implements ActionListener{
	
	static String buttonClicked = "";

	public static void main(String[] args) {
		Client c = new Client();
		MenuBuilder b = new MenuBuilder();
		Director d = new Director(b);
		
		d.makeHomeGUI();
		Menu homeGUI = b.getProduct();
		JButton[] homeButtons = homeGUI.getButtons();
		for ( int i=0; i<homeButtons.length; i++ )
			homeButtons[i].addActionListener(c);
		homeGUI.setVisible(true);
	
	
		if ( buttonClicked.equals("Stanze") ) {
			d.makeRoomListGUI();
			Menu roomListGUI = b.getProduct();
			JButton[] roomListButtons = roomListGUI.getButtons();
			for ( int i=0; i<roomListButtons.length; i++ )
				roomListButtons[i].addActionListener(c);
			roomListGUI.setVisible(true);
		}
		
			
		

	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton jb = (JButton)e.getSource();
		if ( jb.getText().equals("Opere") )
			System.out.println("Hai cliccato Opere");
		else if ( jb.getText().equals("Stanze") )
			//System.out.println("Hai cliccato Stanze");
			buttonClicked = "Stanze";

		
	}
	
		

}
