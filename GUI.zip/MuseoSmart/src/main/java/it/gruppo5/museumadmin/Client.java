package it.gruppo5.museumadmin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;


public class Client implements ActionListener{
	
	static String buttonClicked = "";

	public static void main(String[] args) throws InterruptedException {
		Client c = new Client();
		MenuBuilder b = new MenuBuilder();
		Director d = new Director(b);
		
		// home GUI
		d.makeHomeGUI();
		Menu homeGUI = b.getProduct();
		JButton[] homeButtons = homeGUI.getButtons();
		for ( int i=0; i<homeButtons.length; i++ )
			homeButtons[i].addActionListener(c);
		homeGUI.setVisible(true);
	
		// room list GUI
		d.makeRoomListGUI();
		Menu roomListGUI = b.getProduct();
		JButton[] roomListButtons = roomListGUI.getButtons();
		for ( int i=0; i<roomListButtons.length; i++ )
			roomListButtons[i].addActionListener(c);

		
		// artwork list GUI
		
		// room GUI
		
		// artwork GUI
		
		
		while ( true ) {
			Thread.sleep(300);
			if ( buttonClicked.equals("Stanze") )
				roomListGUI.setVisible(true);
			else if ( buttonClicked.equals("Opere") )
				System.out.println("Hai cliccato Opere");
			
				
			buttonClicked = "";
		}



	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton jb = (JButton)e.getSource();
		buttonClicked = jb.getText();
	}
	
}
