package it.gruppo5.museumadmin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class MenuBuilder implements Builder{
	
	private Menu menu;
	private JPanel panel;
	private JButton[] buttons;
	
	
	public MenuBuilder () {
		this.reset();
	}
	

	@Override
	public void reset(){
		this.panel = new JPanel();
		this.buttons = null;
		
	}

	@Override
	public void createWindow (String title) {
		this.menu = new Menu (title);
		//this.menu.setTitle(title);
		//this.menu.setSize(width, height);
		this.menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.menu.setSize(600, 400);
	}
	
	@Override
	public void createPanel () {
		this.panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
		this.panel.setLayout(new GridLayout(1,0));
		this.menu.add(this.panel, BorderLayout.CENTER);
	}
	
	
	
	public void createButtons (String ... args) {
		
		this.buttons = new JButton [args.length];
		
		for ( int i=0; i<args.length; i++ ) {
			this.buttons[i]= new JButton(args[i]);
			this.buttons[i].setPreferredSize(new Dimension(100,50));
			this.panel.add(this.buttons[i]);
		}

	}
	
	
	public Menu getProduct () {
		//return new Menu(this.panel, this.buttons);
		this.menu.setButtons(this.buttons);
		return this.menu;
	}

}