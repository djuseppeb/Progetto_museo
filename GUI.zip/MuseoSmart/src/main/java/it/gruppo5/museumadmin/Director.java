package it.gruppo5.museumadmin;


public class Director {
	private Builder b;
	
	public Director (Builder b) {
		this.b = b;
	}
	
	public void changeBuilder (Builder b) {
		this.b = b;
	}
	
	public void makeHomeGUI () {
		b.reset();
		b.createWindow("Home");
		b.createPanel();
		b.createButtons("Opere", "Stanze");
	}
	
	public void makeRoomListGUI () {
		b.reset();
		b.createWindow("Lista Stanze");
		b.createPanel();
		b.createButtons("Stanza 1", "Stanza 2", "Stanza 3", "Stanza 4");
	}
}
