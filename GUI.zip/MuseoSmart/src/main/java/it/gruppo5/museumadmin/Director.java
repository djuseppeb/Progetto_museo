package it.gruppo5.museumadmin;

import javax.swing.JFrame;

public class Director {
	private Builder b;
	
	public Director (Builder b) {
		this.b = b;
	}
	
	public void changeBuilder (Builder b) {
		this.b = b;
	}
	
	public void makeHomeGUI () {
		b.reset();
		b.createWindow("Home", JFrame.EXIT_ON_CLOSE);
		b.createPanel();
		b.createButtons("Opere", "Stanze");
	}
	
	public void makeRoomListGUI () {
		b.reset();
		b.createWindow("Lista Stanze", JFrame.DISPOSE_ON_CLOSE);
		b.createPanel();
		b.createButtons("Stanza 1", "Stanza 2", "Stanza 3", "Stanza 4");
	}
}
