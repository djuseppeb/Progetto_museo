package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class RoomCreator implements Creator{
    Connection conn = DbAccess.getAccess().conn;

	@Override
	public Component createComponent(int ID) {
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM art_piece where ID_art = " +  ID );
        
        
		return new Room(rs.getInt("ID_room"), 
				rs.getFloat("Temperature"), 
				rs.getBoolean("Status_thermal_system"), 
				rs.getInt("N_people"), 
				rs.getFloat("Average_distance"), 
				rs.getBoolean("Social_distancing"), 
				rs.getInt("light_intensity"));
	}
}
