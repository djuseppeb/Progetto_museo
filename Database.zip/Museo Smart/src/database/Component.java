package database;

public interface Component {
	
	public int getID();
}
