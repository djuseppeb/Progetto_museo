package database;


public interface Creator {
	//abstract methods
	public abstract Component createComponent(int ID);


}