package database;

public class Main {

	public static void main(String[] args) {
		Creator test = new OperaCreator();
		Opera art2 = (Opera) test.createComponent(2);
		System.out.println(art2.getTitle());
		
	}

}
