package Creator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public abstract class DBAccess {
	private static DBAccess access = null;
	Connection conn = null;
	
	//Costructor
	private DBAccess() {}
	
	//Single istance(Pattern Singleton)
	public static DBAccess getAccess() {
		if(access  == null) {
			try {
				//connection to DB
				String url = "jdbc:mysql://localhost:3306/gestione_museo";
				conn = DriverManager.getConnection(url,"root","");
				Statement stmt = conn.createStatement();
				access = new DBAccess();
			}
			catch (Exception e) {
	            System.err.println("DB ERROR! ");
	            System.err.println(e.getMessage());
	    }
			
		}
		return access;
	}
	
	//abstract methods
	public Room createStanza(int ID);
	public Opera createOpera(int ID);

}