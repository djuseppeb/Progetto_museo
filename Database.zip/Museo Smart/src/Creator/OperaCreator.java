package Creator;

public class OperaCreator extends DBAccess{
	
	@override
	public Opera createOpera(int ID) {
		//fare le query
		return new Opera(/*dati presi dalle query*/);
	};
}
