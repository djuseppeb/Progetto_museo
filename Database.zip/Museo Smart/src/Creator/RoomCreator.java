package Creator;

public class RoomCreator extends DBAccess{

	@override
	public Room createRoom(int ID) {
		//fare le query
		return new Room(/*dati presi dalle query*/);
	};
}
