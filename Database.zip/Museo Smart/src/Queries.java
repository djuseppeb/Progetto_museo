import java.sql.*;
import java.util.Properties;

public class Queries {

    public static void main(String[] args) {
        Queries test = new Queries();
        Connection conn = null;
        try {
            String url = "jdbc:mysql://localhost:3306/gestione_museo";
            conn = DriverManager.getConnection(url,"root","");
            Statement stmt = conn.createStatement();
            ResultSet rs;
 
            rs = stmt.executeQuery("SELECT * FROM opera");
            while ( rs.next() ) {
                String column = rs.getString("Titolo");
                System.out.println(column);
            }
            System.out.println(" DB connected ");
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
    }
        return;
    }

}